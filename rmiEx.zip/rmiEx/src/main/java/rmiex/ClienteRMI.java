/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rmiex;

import java.rmi.Naming;

public class ClienteRMI {
    
    public static void main(String[] args) throws Exception{
        String objName ="rmi://localhost:1099/Calc";
        ICalculadora calc = (ICalculadora) Naming.lookup(objName);
        System.out.println("O resultado da some é: " + calc.adicao(3,5));
    }
}
