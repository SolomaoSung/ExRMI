package rmiex;

import java.rmi.Remote;
import java.rmi.RemoteException;


public interface ICalculadora extends Remote{
    int adicao(int x, int y) throws RemoteException;
}
