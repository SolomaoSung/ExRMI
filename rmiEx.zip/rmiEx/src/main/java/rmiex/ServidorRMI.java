/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rmiex;

//"rmic -keep Calculadora"

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;

public class ServidorRMI {
    
    public static void main(String[] args) {
        try {
            ICalculadora calc = new Calculadora();
            String objName = "rmi://localhost/Calc";
            
            System.out.println("Registrando o objeto no RMI registrador.");
            LocateRegistry.createRegistry(1099);
            Naming.rebind(objName, calc);
            
            System.out.println("Aguardando clientes");
       
        } catch (Exception e) {
            e.printStackTrace();
        
        }
        }
    }

