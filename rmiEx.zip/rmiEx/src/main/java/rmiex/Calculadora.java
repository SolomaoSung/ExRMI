/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rmiex;

import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;

public class Calculadora extends UnicastRemoteObject implements ICalculadora{
    public Calculadora() throws RemoteException {
        
    }
    @Override
    public int adicao(int x, int y) throws RemoteException {
        return x + y;
    }
    
}
